<footer class="footer">
    <div class="footer_tematika">
        <h3 class="tematika">tematika &nbsp &nbsp<i class="fa-solid fa-book fa-lg" style="color:rgba(12, 12, 98, 0.834); "></i> </h3>
    </div>
</footer> <!--  practicando  -->